# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: place-crud.spec.ts >> 新增、編輯景點與詳細資訊會保存到 Firebase Emulator
- Location: e2e\place-crud.spec.ts:28:1

# Error details

```
Error: TripDetail 應註冊 Emulator E2E 景點新增 hook

TripDetail 應註冊 Emulator E2E 景點新增 hook

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 10000ms exceeded while waiting on the predicate
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test';
  2   | 
  3   | import {
  4   |   clearEmulatorDatabase,
  5   |   readEmulatorData,
  6   |   seedTestTrip,
  7   | } from './support/emulator';
  8   | 
  9   | const ROOM_ID = 'e2eplacecrudroom0001';
  10  | const ORIGINAL_NAME = 'E2E 測試餐廳';
  11  | const EDITED_NAME = 'E2E 已編輯餐廳';
  12  | const EDITED_NOTE = 'E2E 編輯後筆記';
  13  | 
  14  | type PlaceItem = {
  15  |   id?: string;
  16  |   name?: string;
  17  |   customName?: string;
  18  |   time?: string;
  19  |   stayTime?: string | number;
  20  |   memo?: string;
  21  | };
  22  | 
  23  | test.beforeEach(async () => {
  24  |   await clearEmulatorDatabase();
  25  |   await seedTestTrip(ROOM_ID);
  26  | });
  27  | 
  28  | test('新增、編輯景點與詳細資訊會保存到 Firebase Emulator', async ({
  29  |   page,
  30  | }) => {
  31  |   await page.goto(`/?room=${ROOM_ID}`);
  32  | 
  33  |   await expect(page.getByTestId('active-trip-view')).toBeVisible({
  34  |     timeout: 20_000,
  35  |   });
  36  | 
  37  |   await expect
  38  |     .poll(
  39  |       async () =>
  40  |         await page.evaluate(
  41  |           () =>
  42  |             typeof (
  43  |               window as Window & {
  44  |                 __TRAVEL_E2E__?: {
  45  |                   addTestPlace?: () => void;
  46  |                 };
  47  |               }
  48  |             ).__TRAVEL_E2E__?.addTestPlace === 'function',
  49  |         ),
  50  |       {
  51  |         timeout: 10_000,
  52  |         message: 'TripDetail 應註冊 Emulator E2E 景點新增 hook',
  53  |       },
  54  |     )
> 55  |     .toBe(true);
      |      ^ Error: TripDetail 應註冊 Emulator E2E 景點新增 hook
  56  | 
  57  |   await page.evaluate(() => {
  58  |     const e2eWindow = window as Window & {
  59  |       __TRAVEL_E2E__?: {
  60  |         addTestPlace?: () => void;
  61  |       };
  62  |     };
  63  | 
  64  |     e2eWindow.__TRAVEL_E2E__?.addTestPlace?.();
  65  |   });
  66  | 
  67  |   let placeCard = page
  68  |     .getByTestId('place-card')
  69  |     .filter({ hasText: ORIGINAL_NAME })
  70  |     .first();
  71  | 
  72  |   await expect(placeCard).toBeVisible({
  73  |     timeout: 15_000,
  74  |   });
  75  | 
  76  |   await expect
  77  |     .poll(
  78  |       async () => {
  79  |         const dayItems = await readEmulatorData<PlaceItem[]>(
  80  |           `rooms/${ROOM_ID}/itinerary/Day 1`,
  81  |         );
  82  | 
  83  |         return Array.isArray(dayItems)
  84  |           ? dayItems.some((item) => item.name === ORIGINAL_NAME)
  85  |           : false;
  86  |       },
  87  |       {
  88  |         timeout: 15_000,
  89  |         message: '新增景點後應寫入 Database Emulator',
  90  |       },
  91  |     )
  92  |     .toBe(true);
  93  | 
  94  |   await page.reload();
  95  | 
  96  |   placeCard = page
  97  |     .getByTestId('place-card')
  98  |     .filter({ hasText: ORIGINAL_NAME })
  99  |     .first();
  100 | 
  101 |   await expect(placeCard).toBeVisible({
  102 |     timeout: 20_000,
  103 |   });
  104 | 
  105 |   await placeCard.click();
  106 | 
  107 |   await expect(page.getByTestId('place-detail-sheet')).toBeVisible();
  108 |   await expect(page.getByTestId('place-detail-title')).toHaveText(
  109 |     ORIGINAL_NAME,
  110 |   );
  111 | 
  112 |   await page.getByTestId('place-detail-edit-button').click();
  113 | 
  114 |   await expect(page.getByTestId('edit-place-modal')).toBeVisible();
  115 | 
  116 |   await page.getByTestId('place-name-input').fill(EDITED_NAME);
  117 |   await page.getByTestId('place-arrival-time-input').fill('12:30');
  118 |   await page.getByTestId('place-stay-duration-input').fill('75');
  119 |   await page.getByTestId('place-note-input').fill(EDITED_NOTE);
  120 |   await page.getByTestId('save-place-button').click();
  121 | 
  122 |   placeCard = page
  123 |     .getByTestId('place-card')
  124 |     .filter({ hasText: EDITED_NAME })
  125 |     .first();
  126 | 
  127 |   await expect(placeCard).toBeVisible({
  128 |     timeout: 15_000,
  129 |   });
  130 | 
  131 |   await expect
  132 |     .poll(
  133 |       async () => {
  134 |         const dayItems = await readEmulatorData<PlaceItem[]>(
  135 |           `rooms/${ROOM_ID}/itinerary/Day 1`,
  136 |         );
  137 | 
  138 |         const editedPlace = Array.isArray(dayItems)
  139 |           ? dayItems.find((item) => item.customName === EDITED_NAME)
  140 |           : null;
  141 | 
  142 |         return editedPlace
  143 |           ? {
  144 |               customName: editedPlace.customName,
  145 |               time: editedPlace.time,
  146 |               stayTime: String(editedPlace.stayTime),
  147 |               memo: editedPlace.memo,
  148 |             }
  149 |           : null;
  150 |       },
  151 |       {
  152 |         timeout: 15_000,
  153 |         message: '編輯後的景點資料應寫入 Database Emulator',
  154 |       },
  155 |     )
```